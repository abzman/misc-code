The library is made by Marzogh (and original location is here: https://github.com/Marzogh/SPIMemory/) we just extended the support for EN25QH16B SPI memory made by EON.

Until new SPI flash memory EN25QH16B by EON gets supported by the oriignal library, please manually add the library  to your Arduino IDE. This is done from Sketch -> Include Library -> Add .ZIP library...

You can track if the EN25QH16B memory had been added in the library here:

https://github.com/Marzogh/SPIMemory/pull/229